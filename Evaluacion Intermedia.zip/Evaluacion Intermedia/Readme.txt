Integrantes:

Francisca Lastra
Jeffrey Bustamante
Javiera Arismendi
Jeison Rubiano
Ruben Quintana

Contextualizacion de Problema:

Para el desarrollo de la solución tecnológica es necesaria la creación de archivos html que 
que al publicarse en servidores web se logre el acceso a la información actualizada
de los diferentes procesos del negocio, el control de actividades,
la coordinación entre la empresa, los profesionales y los clientes para la respuesta 
temprana ante incidentes de seguridad.

A partir de los siguiente archivos se podrá distribuir, acceder y gestionar la información de manera organizada.

Pgina principal
- index.html.

Para contactarse y realizar consultas a la empresa:
- contacto.html

Para crear la capacitacion:
- crearcapacitacion.html

Para conocer las capacitaciones creadas
- listarcapacitaciones.html
- listadousuarios.html 
- crearusuario.html

Para lograr la correcta publicacion de los datos de usuarios tipo profesional, administrativo y cliente es
necesaria la posibilidad de editarlos mediante el uso de formuarios en documentos html,
los cuales con el boton "Editar Usuario" se puedan modificar cualquier dato mal ingresado.
Esto mediante los documentos editarprofesional.html, editaradministrativo.html,editarcliente.html.

- editarcliente.html
- editaradministrativo.html
- editarprofesional.html

Estos documentos fueron realizados con un diseño unico mediante el uso de hojas de estilo: style.css
Se realiza un diseño de pagina responsivo para 3 tipos de dispositivos.




